# PDF Studio (Android)

Free PDF reader/editor: read, search, annotate, sign, rotate, delete, reorder, merge, extract pages, export PNG/TXT. Works fully offline; files never leave the device.

## Build the APK (pick one)

### A) Android Studio (Windows/Mac/Linux)
1. Install Node 18+ and Android Studio.
2. In this folder: `npm install`
3. `npm run open`  (copies libs, syncs, opens Android Studio)
4. Android Studio: Build > Build APK(s). Or run on your phone with USB debugging.

### B) No Android Studio: GitHub Actions
1. Create a GitHub repo and upload this folder's contents.
2. Actions tab > "Build APK" > Run workflow.
3. Download `pdf-studio-debug-apk` from the run, unzip, install `app-debug.apk` (allow "install unknown apps").

## Edit the app
All UI/logic is in `www/index.html`. After changes: `npm run sync`.

## Release to Play Store
Build a signed AAB in Android Studio (Build > Generate Signed Bundle), and replace the appId in `capacitor.config.json` with your own.
