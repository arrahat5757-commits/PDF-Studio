package com.example.pdfstudio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
