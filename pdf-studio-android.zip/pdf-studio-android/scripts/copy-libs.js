const fs=require('fs'),path=require('path');
const copy=(from,to)=>{fs.mkdirSync(path.dirname(to),{recursive:true});fs.copyFileSync(from,to);console.log('copied',to)};
copy('node_modules/pdfjs-dist/build/pdf.min.js','www/lib/pdf.min.js');
copy('node_modules/pdfjs-dist/build/pdf.worker.min.js','www/lib/pdf.worker.min.js');
copy('node_modules/pdf-lib/dist/pdf-lib.min.js','www/lib/pdf-lib.min.js');
